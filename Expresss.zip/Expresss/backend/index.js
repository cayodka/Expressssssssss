const express = require('express');
const auth = require('./src/Auth.js');

const auth = new Auth();