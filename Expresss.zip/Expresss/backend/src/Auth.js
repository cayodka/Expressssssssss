class auth {

}

module.exports = Auth;